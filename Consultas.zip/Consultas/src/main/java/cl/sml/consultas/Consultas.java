/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cl.sml.consultas;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import java.io.IOException;
import java.io.InputStreamReader;
import org.bson.types.ObjectId;

/**
 *
 * @author Javier
 */
public class Consultas {

    private static String dataBase;
    private static String coleccionIndice;
    private static String coleccionDocumentos;
    private static String indiceInvertido;

    public static void main(String[] args) throws FileNotFoundException, IOException {

        DB database;
        try (BufferedReader entrada = new BufferedReader(new FileReader("datos.ini"))) {
            database = null;
            try {
                dataBase = entrada.readLine();
                indiceInvertido = entrada.readLine();
                coleccionDocumentos = entrada.readLine();
                coleccionIndice = entrada.readLine();

                MongoClient mongoClient = new MongoClient();
                database = mongoClient.getDB(dataBase);

            } catch (Exception e) {
                System.err.println(e.getClass().getName() + ": " + e.getMessage());
            }
            entrada.close();
        }

        DBCollection indiceInvertido = database.getCollection(coleccionIndice);
        DBCollection documento = database.getCollection(coleccionDocumentos);

        while (true) {

            BufferedReader lector = new BufferedReader(new InputStreamReader(System.in));
            String consulta = lector.readLine().toUpperCase();
            BasicDBObject query = new BasicDBObject("palabra", consulta);
            DBCursor cursor = indiceInvertido.find(query);
            if (cursor.count() == 0) {
                System.out.println("Busqueda sin resultados: " + consulta);
            } else {
                while (cursor.hasNext()) {

                    BasicDBList privileges = (BasicDBList) cursor.next().get("documento");
                    System.out.println(privileges.size());
                    for (int i = 0; i < privileges.size(); i++) {
                        System.out.println(privileges.get(i));

                    }

                    //DBObject obj = cursor.next();
                    //Object value = obj.get("documento");
                    //System.out.println(value);
                }
            }
        }

    }
}
